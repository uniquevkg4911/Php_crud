<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $staffId = $_POST['staffId'];
    $subjectIds = $_POST['subjectIds'];

    // Split subject IDs into an array
    $subjectIdArray = explode(',', $subjectIds);

    // Link staff and subjects in the database
    foreach ($subjectIdArray as $subjectId) {
        // Insert staff-subject relationship into Staff_Subjects table
        $sql = "INSERT INTO staff_subjects (staff_id, subject_id) VALUES ('$staffId', '$subjectId')";
        $result = mysqli_query($conn, $sql);
        
        if (!$result) {
            // Error linking staff and subjects
            echo "Error linking staff and subjects: " . mysqli_error($conn);
            return;
        }
    }

    // Staff and subjects linked successfully
    echo "Staff and subjects linked successfully!";
}
?>
