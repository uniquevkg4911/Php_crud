<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get current year
    $currentYear = date('Y');

    // Delete students from the completed batch from the database
    $sql = "DELETE FROM students WHERE batch < '$currentYear'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Completed batch students removed successfully
        echo "Completed batch students removed successfully!";
    } else {
        // Error removing completed batch students
        echo "Error removing completed batch students: " . mysqli_error($conn);
    }
}
?>
