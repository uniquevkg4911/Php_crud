<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $staffName = $_POST['staffName'];
    $staffDepartment = $_POST['staffDepartment'];
    $staffMobile = $_POST['staffMobile'];
    $staffAddress = $_POST['staffAddress'];

    // Insert staff data into the database
    $sql = "INSERT INTO staff (name, department, mobile, address) 
            VALUES ('$staffName', '$staffDepartment', '$staffMobile', '$staffAddress')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Staff added successfully
        echo "Staff added successfully!";
    } else {
        // Error adding staff
        echo "Error adding staff: " . mysqli_error($conn);
    }
}
?>
