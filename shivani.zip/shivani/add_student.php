<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $name = $_POST['name'];
    $rollNumber = $_POST['rollNumber'];
    $department = $_POST['department'];
    $batch = $_POST['batch'];
    $gender = $_POST['gender'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];

    // Insert student data into the database
    $sql = "INSERT INTO students (name, roll_number, department, batch, gender, mobile, address) 
            VALUES ('$name', '$rollNumber', '$department', '$batch', '$gender', '$mobile', '$address')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Student added successfully
        echo "Student added successfully!";
    } else {
        // Error adding student
        echo "Error adding student: " . mysqli_error($conn);
    }
}
?>
