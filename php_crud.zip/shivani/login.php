<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"  href="style.css">

    <title>Hello, world!</title>
    <style>
      body{
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: url('4.jpg') no-repeat;
    background-size: cover;
    background-position: center;
}
h1 {
    position: absolute;
    top: 0;
    margin-top: 20px;
  }
      </style>
  </head>
  <body>
      <h1 style="color: white;">Attendance System</h1>
  <?php
    require('db.php');
    session_start();
    // When form submitted, check and create user session.
    if (isset($_POST['username'])) {
        $username = stripslashes($_REQUEST['username']);    // removes backslashes
        $username = mysqli_real_escape_string($con, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        // Check user is exist in the database
        $query    = "SELECT * FROM `users` WHERE username='$username'
                     AND password='" . md5($password) . "'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['username'] = $username;
            // Redirect to user dashboard page
            header("Location:http://127.0.0.1:50100");
        } else {
            echo "<div class='form'>
                  <h3>Incorrect Username/password.</h3><br/>
                  <p class='link'>Click here to <a href='login.php'>Login</a> again.</p>
                  </div>";
        }
    } else {
?>

<div class="wrapper">
    <form class="form" method="post" name="login">
        <h1 style="color:white;">Login</h1>
        <br><br>
        <h1 class="login-title" ></h1>
        <h3 style="color:white;"><input type="text" class="login-input" name="username" placeholder="Username" autofocus="true"/> User name</h2>
        <br>
        <h3 style="color:white;"><input type="password" class="login-input" name="password" placeholder="Password"/> password</h2>
        <br>
        <input type="submit" value="Login" name="submit" class="login-button"/>
        <button>
        <a href="new.php">Click me!</a>
        </button>

        <br>
    </a>
        
        <br>
        <p class="link"><a href="registration.php"  style="color: white;" >Click to Register</a></p>
  </form>
</div>
  <?php
    }
?>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


  </body>
</html>