<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $firstYear = $_POST['firstYear'];
    $secondYear = $_POST['secondYear'];
    $thirdYear = $_POST['thirdYear'];

    // Update batch details in the database
    $sql = "UPDATE batch SET first_year='$firstYear', second_year='$secondYear', third_year='$thirdYear'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Batch details updated successfully
        echo "Batch details updated successfully!";
    } else {
        // Error updating batch details
        echo "Error updating batch details: " . mysqli_error($conn);
    }
}
?>
