<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">

    <title>Student List</title>
</head>
<?php
include 'db.php';
$result = mysqli_query($conn,"SELECT * FROM students");
?>

<body>
    <div class="container mt-5">

        <div class="row">
            <div class="col-md-10">
                <h2 class="text-center bg-light py-2" style="color: #226bb5;">Student List</h2>
                <?php
if (mysqli_num_rows($result) > 0) {
?>
                <table id="myTable" class="display  mt-3">
                    <thead>
                        <tr>
                            <th>Student Id</th>
                            <th>Name</th>
                            <th>Roll Number</th>
                            <th>Department</th>
                            <th>Batch</th>
                            <th>Gender</th>
                            <th>Mobile</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
while($row = mysqli_fetch_array($result)) {
?>
                        <tr>
                            <td><?php echo $row['id'];?></td>
                            <td><?php echo $row['name'];?></td>
                            <td><?php echo $row['roll_number'];?></td>
                            <td><?php echo $row['department'];?></td>
                            <td><?php echo $row['batch'];?></td>
                            <td><?php echo $row['gender'];?></td>
                            <td><?php echo $row['mobile'];?></td>
                            <td><?php echo $row['address'];?></td>
                            <td class="d-flex"><a type="button" class="btn btn-primary" href="update_student.php?studentId=<?php echo $row["id"]; ?>">Update</a>&nbsp;<a type="button" class="btn btn-danger" name="submit" href="remove_student.php?studentId=<?php echo $row["id"]; ?>">Delete</a></td>
                        </tr>
                        <?php
}
?>

                    </tbody>
                </table>
                <?php
}
else{
echo "No result found";
?><br>
<a href="index.php" type="button" class="btn btn-primary mt-3">Home page</a>

<?php
}
?>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>

</body>

</html>