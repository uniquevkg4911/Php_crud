<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <title>University Management System</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.18/sweetalert2.min.js"></script>
</head>
<?php
// Include database connection
include 'db.php';

$studentId = $_GET['studentId'];

// Check if the form is submitted (POST request)
if (isset($_POST['submit'])) {
    // Get student ID to remove
    echo $studentId;

    // Delete student from the database
    $sql = "DELETE FROM students WHERE id = $studentId";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Student removed successfully
        echo "<script>alert('Data Deleted Successfully!!');</script>";
  header("Location: search_student.php");

    } else {
        // Error removing student
        echo "Error removing student: " . mysqli_error($conn);
    }
}
?>

<body>
    <h1 class="text-center py-2" style="background: rgb(250, 235, 215); color: rgb(165, 42, 42);">University Management
        System</h1>
    <div class="container">
        <h2 class="text-center bg-light py-2" style="color: #226bb5;">Administrator Login</h2>
        <div class="row">
           
            <form class="col-md-12" action="" method="POST">
                <div class="row mt-4">
                <div class="col-12">
                <a type="button" href="search_student.php" class="btn btn-primary">Back</a>
            </div>
                    <div class="col-md-6 mb-3">
                        <label for="studentId" class="form-label">Student Id</label>
                        <input type="text" class="form-control" value="<?php echo $studentId?>" id="studentId" name="studentId" required
                            placeholder="Enter Roll Number" />
                    </div>
                   
                    <div class="col-md-6 mt-4">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete?')" name="submit" class="btn btn-danger">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>




    <!-- <script src="script.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('studentId').disabled = true;

    </script>


</body>

</html>