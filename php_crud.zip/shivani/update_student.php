
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <title>University Management System</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.7.18/sweetalert2.min.js"></script>
</head>
<?php
// Include database connection
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $studentId = $_POST['studentId'];
    $name = $_POST['name'];
    $rollNumber = $_POST['rollNumber'];
    $department = $_POST['department'];
    $batch = $_POST['batch'];
    $gender = $_POST['gender'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];

    $showData = mysqli_query($conn,"SELECT * FROM `students`"); 

    // Update student data in the database
    $sql = "UPDATE students SET name='$name', roll_number='$rollNumber', department='$department', batch='$batch', 
            gender='$gender', mobile='$mobile', address='$address' WHERE id='$studentId'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Student updated successfully
  echo "<script>alert('Data Updated Successfully!!');</script>";
    } else {
        // Error updating student
        echo "Error updating student: " . mysqli_error($conn);
    }
}
?>

<body>
    <h1 class="text-center py-2" style="background: rgb(250, 235, 215); color: rgb(165, 42, 42);">University Management
        System</h1>
    <div class="container">
        <h2 class="text-center bg-light py-2" style="color: #226bb5;">Administrator Login</h2>
        <div class="row">
            <form class="col-md-12" action="" method="POST">
                <div class="row mt-4">
                    <div class="col-12">
                        <a type="button" class="btn btn-primary" href="search_student.php">Back</a>
                    </div>
                    <div class="col-md-6 mb-3">
                    <input type="hidden" name="studentId" value="">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required
                            placeholder="Enter Name" />
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="rollNumber" required class="form-label">Roll Number</label>
                        <input type="text" class="form-control" id="rollNumber" name="rollNumber" required
                            placeholder="Enter Roll Number" />
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="department" required class="form-label">Department</label>
                        <input type="text" class="form-control" id="department" name="department" required
                            placeholder="Enter Department" />
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="batch" class="form-label">Batch</label>
                        <input type="text" required class="form-control" id="batch" name="batch"
                            placeholder="Enter Batch" />
                        <div class="invalid-feedback">Please enter a valid batch.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select class="form-control" id="floatingSelect" name="gender" required
                            aria-label="Floating label select example" style="width: 100%;">
                            <option disabled selected>Open this select menu</option>
                            <option value="Male">One</option>
                            <option value="Female">Two</option>
                            <option value="Other">Three</option>
                        </select>

                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="mobile" class="form-label">Mobile</label>
                        <input type="text" class="form-control" id="mobile" required name="mobile"
                            placeholder="Enter Mobile" />

                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" required name="address"
                            placeholder="Enter Address" />
                    </div>
                    <div class="col">
                        <button type="submit" name="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>





    <!-- <script src="script.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

   

</body>

</html>
