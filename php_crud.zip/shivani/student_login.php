<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get login credentials
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Search for student with the provided username and password
    $sql = "SELECT * FROM students WHERE roll_number = '$username' AND mobile = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        // Student found, display details
        $student = mysqli_fetch_assoc($result);
        echo "Student Details:<br>";
        echo "Name: " . $student['name'] . "<br>";
        echo "Roll Number: " . $student['roll_number'] . "<br>";
        echo "Department: " . $student['department'] . "<br>";
        echo "Batch: " . $student['batch'] . "<br>";
        echo "Gender: " . $student['gender'] . "<br>";
        echo "Mobile: " . $student['mobile'] . "<br>";
        echo "Address: " . $student['address'] . "<br>";
    } else {
        // Invalid login credentials
        echo "Invalid username or password.";
    }
}
?>
