<?php
// Include database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $subjectName = $_POST['subjectName'];
    $subjectDepartment = $_POST['subjectDepartment'];

    // Insert subject data into the database
    $sql = "INSERT INTO subjects (name, department) VALUES ('$subjectName', '$subjectDepartment')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Subject added successfully
        echo "Subject added successfully!";
    } else {
        // Error adding subject
        echo "Error adding subject: " . mysqli_error($conn);
    }
}
?>
