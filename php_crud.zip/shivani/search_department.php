<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">

    <title>Department List</title>
</head>
<?php
include 'db.php';
$result = mysqli_query($conn,"SELECT * FROM departments");
?>

<body>
    <div class="container mt-5">

        <div class="row">
            <div class="col-md-10">
                <h2 class="text-center bg-light py-2" style="color: #226bb5;">Department List</h2>
                <?php
if (mysqli_num_rows($result) > 0) {
?>
                <table id="myTable" class="display  mt-3">
                    <thead>
                        <tr>
                            <th>Department Id</th>
                            <th>Department Name</th>
                            <th>Department Short Name</th>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
while($row = mysqli_fetch_array($result)) {
?>
                        <tr>
                            <td><?php echo $row['id'];?></td>
                            <td><?php echo $row['department_name'];?></td>
                            <td><?php echo $row['short_name'];?></td>
                            <td class="d-flex"><a type="button" class="btn btn-primary"
                                    href="update_department.php?studentId=<?php echo $row["id"]; ?>">Update</a>&nbsp;<a
                                    type="button" class="btn btn-danger" name="submit"
                                    href="remove_department.php?studentId=<?php echo $row["id"]; ?>">Delete</a></td>
                        </tr>
                        <?php
}
?>

                    </tbody>
                </table>
                <?php
}
else{
echo "No result found";
?><br>
<a href="add_department.php" type="button" class="btn btn-primary mt-3">Home Page</a>

<?php
}
?>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>

</body>

</html>